import { homeSpy } from "./scrollspy";
import { doctors } from "./doctors";

window.homeSpy = homeSpy
window.doctors = doctors;

