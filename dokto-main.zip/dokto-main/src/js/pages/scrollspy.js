export function homeSpy() {
  return {
    activeStep: ''
  }
}