import { theme } from "./theme";
import { navbar } from "./navbar";
import { swiper } from "./swiper";

window.theme = theme;
window.navbar = navbar
window.swiper = swiper